<div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li class="active">
                            <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                         <li class="submenu">
              <a href="#"><i class="fa fa-user"></i> <span> Members </span> <span class="menu-arrow"></span></a>
              <ul style="display: none;">
                <li><a href="add-member.php">Add Member</a></li>
                <li><a href="manage-member.php">Manage Member</a></li>
               
              </ul>
            </li>
               <li class="submenu">
              <a href="#"><i class="fa fa-calendar"></i> <span>B.P Monitoring </span> <span class="menu-arrow"></span></a>
              <ul style="display: none;">
                <li><a href="add-bp.php">Add BP </a></li>
                <li><a href="history-bp.php">History</a></li>
               
              </ul>
            </li> 
            <li class="submenu">
              <a href="#"><i class="fa fa-calendar"></i> <span>Sugar Monitoring </span> <span class="menu-arrow"></span></a>
              <ul style="display: none;">
                <li><a href="add-sugar.php">Add Sugar Measure</a></li>
                <li><a href="history-sugar.php">History</a></li>
               
              </ul>
            </li>
            <li class="submenu">
              <a href="#"><i class="fa fa-calendar"></i> <span>Temprature </span> <span class="menu-arrow"></span></a>
              <ul style="display: none;">
                <li><a href="add-temparture.php">Add Temparture</a></li>
                <li><a href="history-temparture.php">History Temparture</a></li>
               
              </ul>
            </li>          
            <li>
                            <a href="betdates-bpreports.php"><i class="fa fa-flag-o"></i> <span>BP Report</span></a>
                        </li>
                        <li>
                            <a href="betdates-sugarreports.php"><i class="fa fa-flag-o"></i> <span>Blood Sugar Report</span></a>
                        </li>
                        <li>
                            <a href="betdates-tempreports.php"><i class="fa fa-flag-o"></i> <span>Temprature Report</span></a>
                        </li>
         
                </div>
            </div>
        </div>