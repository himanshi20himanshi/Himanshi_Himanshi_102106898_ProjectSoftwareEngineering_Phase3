<div class="sidebar" id="sidebar">
            <div class="sidebar-inner slimscroll">
                <div id="sidebar-menu" class="sidebar-menu">
                    <ul>
                        <li class="menu-title">Main</li>
                        <li class="active">
                            <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
                        </li>
                      <li>
                            <a href="manage-range.php"><i class="fa fa-file"></i> <span>Manage Testing Range</span></a>
                        </li>

                       
                         <li>
              <a href="view-reg-users.php"><i class="fa fa-user"></i> <span> View Reg Users </span> </a>
              
            </li>
              
                   
            <li>
                            <a href="betdates-bpreports.php"><i class="fa fa-flag-o"></i> <span>BP Report</span></a>
                        </li>
                        <li>
                            <a href="betdates-sugarreports.php"><i class="fa fa-flag-o"></i> <span>Blood Sugar Report</span></a>
                        </li>
                        <li>
                            <a href="betdates-tempreports.php"><i class="fa fa-flag-o"></i> <span>Temprature Report</span></a>
                        </li>
         
                </div>
            </div>
        </div>